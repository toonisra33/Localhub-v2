/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  importScripts("sw-notifications.js");
  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "sw-notifications.js",
    "revision": "2a38335c8086c35c5c213c0509b94487"
  }, {
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "a846fa727aa03d15a4f067f27bbcebfa"
  }, {
    "url": "pwa-512x512.png",
    "revision": "a846fa727aa03d15a4f067f27bbcebfa"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1d260d4ddad3f55bb8eef31afeb4ea3e"
  }, {
    "url": "index.html",
    "revision": "a52bf4eb78454861c687aa3e706d716e"
  }, {
    "url": "icon.svg",
    "revision": "7c1698a2de30a071fd332a99e6b19663"
  }, {
    "url": "favicon.ico",
    "revision": "b8db76590371ab2d73d7fa33cbf7e8b0"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "f662240817ee4e6619536db3cb5b045d"
  }, {
    "url": "assets/index-DwFWd8gY.js",
    "revision": null
  }, {
    "url": "assets/index-CczeSM4H.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "f662240817ee4e6619536db3cb5b045d"
  }, {
    "url": "favicon.ico",
    "revision": "b8db76590371ab2d73d7fa33cbf7e8b0"
  }, {
    "url": "icon.svg",
    "revision": "7c1698a2de30a071fd332a99e6b19663"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1d260d4ddad3f55bb8eef31afeb4ea3e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "a846fa727aa03d15a4f067f27bbcebfa"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "a846fa727aa03d15a4f067f27bbcebfa"
  }, {
    "url": "sw-notifications.js",
    "revision": "2a38335c8086c35c5c213c0509b94487"
  }, {
    "url": "manifest.webmanifest",
    "revision": "cda0cf540f0a9281d786935611ebd4e8"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
